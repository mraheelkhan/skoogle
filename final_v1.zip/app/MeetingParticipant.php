<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MeetingParticipant extends Model
{
    //
}
