<?php

namespace App\Http\Controllers;

use App\ReviewReply;
use Illuminate\Http\Request;

class ReviewReplyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ReviewReply  $reviewReply
     * @return \Illuminate\Http\Response
     */
    public function show(ReviewReply $reviewReply)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ReviewReply  $reviewReply
     * @return \Illuminate\Http\Response
     */
    public function edit(ReviewReply $reviewReply)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ReviewReply  $reviewReply
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ReviewReply $reviewReply)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ReviewReply  $reviewReply
     * @return \Illuminate\Http\Response
     */
    public function destroy(ReviewReply $reviewReply)
    {
        //
    }
}
