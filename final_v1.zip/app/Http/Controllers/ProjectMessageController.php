<?php

namespace App\Http\Controllers;

use App\ProjectMessage;
use Illuminate\Http\Request;

class ProjectMessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProjectMessage  $projectMessage
     * @return \Illuminate\Http\Response
     */
    public function show(ProjectMessage $projectMessage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProjectMessage  $projectMessage
     * @return \Illuminate\Http\Response
     */
    public function edit(ProjectMessage $projectMessage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProjectMessage  $projectMessage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProjectMessage $projectMessage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProjectMessage  $projectMessage
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProjectMessage $projectMessage)
    {
        //
    }
}
