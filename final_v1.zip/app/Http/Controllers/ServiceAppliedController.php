<?php

namespace App\Http\Controllers;

use App\ServiceApplied;
use Illuminate\Http\Request;

class ServiceAppliedController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ServiceApplied  $serviceApplied
     * @return \Illuminate\Http\Response
     */
    public function show(ServiceApplied $serviceApplied)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ServiceApplied  $serviceApplied
     * @return \Illuminate\Http\Response
     */
    public function edit(ServiceApplied $serviceApplied)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ServiceApplied  $serviceApplied
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ServiceApplied $serviceApplied)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ServiceApplied  $serviceApplied
     * @return \Illuminate\Http\Response
     */
    public function destroy(ServiceApplied $serviceApplied)
    {
        //
    }
}
