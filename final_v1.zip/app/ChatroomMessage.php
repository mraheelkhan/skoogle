<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatroomMessage extends Model
{
    //
}
