# skoogle
An online skills exchange program
