<?php $__env->startSection('topbanner1'); ?>

    <div class="section-warp ask-me">
		<div class="container clearfix">
			<div class="box_icon box_warp box_no_border box_no_background" box_border="transparent" box_background="transparent" box_color="#FFF">
				<div class="row">
					<div class="col-md-3">
						<h2>Welcome to Skoogle</h2>
						<p>You can ask your question from the experts here at skoogle forum. Typically answer is posted around 1hour.</p>
						<div class="clearfix"></div>
						
						<a class="color button dark_button medium" href="#">Join Now</a>
					</div>
					<div class="col-md-9">
                        <form class="form-style form-style-2" style="background: url('<?php echo e(asset('public/askme/images/chrome.png')); ?>')">
                                <p>
                                    <textarea rows="4" id="question_title" onfocus="if(this.value=='Ask any question and you be sure find your answer ?')this.value='';" onblur="if(this.value=='')this.value='Ask any question and you be sure find your answer ?';">Ask any question and you be sure find your answer ?</textarea>
                                    <i class="icon-pencil"></i>
                                    <span class="color button small publish-question">Ask Now</span>
                                </p>
                        </form>
					</div>
				</div>
			</div>
		</div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-9"  style="overflow: unset; height: auto;">

    <div class="tabs-warp question-tab">
        
        <div class="tab-inner-warp" style="display: block;">
            <div class="tab-inner">
                
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="question question-type-normal">
                    <h2>
                    <a href="<?php echo e(route('ForumShow', $question->id)); ?>"><?php echo e($question->question_title); ?></a>
                    </h2>
                    
                    
                    <div class="question-author">
                        <a href="#" original-title="ahmed" class="question-author-img tooltip-n"><span></span><img alt="" src="<?php echo e(asset('public/img/staff/'.$question->user->avatar)); ?>"></a>
                    </div>
                    <div class="question-inner">
                        <div class="clearfix"></div>
                        <p class="question-desc"><?php echo e($question->question_body); ?></p>
                        <div class="question-details">
                        <span class="question-answered"><i class="icon-ok"></i> <?php echo e($question->status); ?></span>
                            
                        </div>
                        <span class="question-category"><a href="#"><i class="icon-folder-close"></i><?php echo e($question->category->category_name); ?></a></span>
                        <span class="question-date"><i class="icon-time"></i><?php echo e($question->created_at->diffForHumans()); ?></span>
                        
                        <span>
                                <a type="button" href="<?php echo e(route('ForumDeleteUserQuestion', $question->id)); ?>"  class="btn btn-danger report-question btn-sm" >
                                        Delete
                                </a>
                                    
                        </span>
                        
                        
                        
                        <div class="clearfix"></div>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.askme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/forum/myquestions.blade.php ENDPATH**/ ?>