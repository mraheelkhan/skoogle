<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
       <div class="row blog_tow_row">
           <div class="video text-center">
             <h2 class="mb-5"><?php echo e($video->title); ?></h2>
            <iframe src="<?php echo e(asset('public/uploads/videos/' . $video->file_name)); ?>" autoplay="off" width="540" height="310"></iframe>
           <p> <?php echo e($video->description); ?></p>
        </div>
       </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/videoShow.blade.php ENDPATH**/ ?>