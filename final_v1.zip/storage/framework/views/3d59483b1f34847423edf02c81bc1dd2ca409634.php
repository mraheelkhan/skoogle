<?php $__env->startSection('content'); ?>
<section id="signup-new" style="background: url('<?php echo e(asset("public/img/backgroundimg.jpg")); ?>');margin: -170px -60px;background-size: cover;background-position: center;">
    <div class="row">       
    <div class="register-right">

    <div class="sign-up-form1">
        <img src="<?php echo e(asset('public/img/avat.png')); ?>" class="avatar">
        <h1> Sign Up Now</h1>
        <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        <form action="<?php echo e(route('RegisterStore')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="fname" class="form-control" placeholder="First Name" value="<?php echo e(old('fname')); ?>" required>
            </div>
            <div class="form-group">
                <input type="text" name="lname" value="<?php echo e(old('lname')); ?>" class="form-control" placeholder="Last Name" required>
            </div>
            
            <div class="form-group">
                <input type="phone" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" placeholder="Your Phone" required>
            </div>
            <div class="form-group">
                <input type="file" name="image" value="<?php echo e(old('image')); ?>" class="form-control" required>
            </div>
            <div class="form-group">
                <select name="gender" id="gender" class="form-control">
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">other</option>
                </select>
            </div>
            <div class="form-group">
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Your Email" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Your Password" required>
            </div>
                        
            <button type="submit" name='submit' class="btn btn-primary">Sign Up</button>
            <hr>
            <p class="or">OR</p>
            
            <p>Do you have an account? <a href="<?php echo e(url('/login')); ?>">Sign In</a></p>
        </form>
    </div>
    
        
    
    </div>
        
    </div>
        </section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/home/register.blade.php ENDPATH**/ ?>