<div class="site-navbar-wrap js-site-navbar bg-white">
      
    <div class="container">
        <div class="site-navbar bg-light">
        <div class="py-1">
            <div class="row align-items-center">
            <div class="col-2">
            <h2 class="mb-0 site-logo"><a href="<?php echo e(route('JobAll')); ?>">Job<strong class="font-weight-bold">Skoogle</strong> </a></h2>
            </div>
            <div class="col-10">
                <nav class="site-navigation text-right" role="navigation">
                <div class="container">
                    <div class="d-inline-block d-lg-none ml-md-0 mr-auto py-3">
                        <a href="#" class="site-menu-toggle js-menu-toggle text-black">
                            <span class="icon-menu h3"></span></a></div>

                    <ul class="site-menu js-clone-nav d-none d-lg-block">
                        <li><a href="<?php echo e(route('Home')); ?>">
                            <span class="">
                                <span class="icon-plus mr-3"></span> News Feed</span>
                            </a>
                        </li>
                        <li><a href="<?php echo e(route('JobAll')); ?>">All Jobs</a></li>
                        <?php if(auth()->check() && auth()->user()->organization_id != 0): ?>
                        
                            <?php if(auth()->user()->isPro == 1 ): ?>
                            <li><a href="<?php echo e(route('MyPostedJobs')); ?>">My Posted Jobs</a></li>
                            <?php endif; ?>

                            <?php endif; ?>      
                    <li><a href="<?php echo e(route('JobCreate')); ?>">
                        <span class="bg-primary text-white py-3 px-4 rounded">
                            <span class="icon-plus mr-3"></span>Post New Job</span>
                        </a>
                    </li>
                    </ul>
                </div>
                </nav>
            </div>
            </div>
        </div>
        </div>
    </div>
</div>
    
<div style="height: 113px;"></div><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/layouts/jobpartials/topmenu.blade.php ENDPATH**/ ?>