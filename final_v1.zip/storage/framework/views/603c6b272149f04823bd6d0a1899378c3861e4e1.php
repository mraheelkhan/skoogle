<?php $__env->startSection('content'); ?>

    <!--------------------ARTICLES START------------------------->
    <section class="blog_tow_area">
        <div class="container">
                <?php if(Session::has('message')): ?>
                <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
            <?php elseif(Session::has('error')): ?>
                <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
            <?php endif; ?>
            <?php if(session('failed')): ?>
                <script>
                  $( document ).ready(function() {
                    swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
                  });
                  
                </script>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
            <div class="row blog_tow_row mb-5 text-center">
                <a href="<?php echo e(route('PostCreate')); ?>" class="btn btn-primary">Write a New Article</a>
            </div>
            <?php endif; ?>
           <div class="row blog_tow_row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6">
                    <div class="renovation">
                        <img class="" style="border: 1px solid black;" src="<?php echo e(asset('public/uploads/postImages/' . $post->image)); ?>" class="img-responsive" style="width: 100%;" alt="">
                        <div class="renovation_content">
                                <a class="clipboard" href="#"><i class="fa fa-clipboard" aria-hidden="true"></i></a>
                                <?php if(auth()->user()->id == $post->user_id): ?>
                                <div class="text-right">
                                        <a href="<?php echo e(route('PostDelete', $post->id)); ?>" class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                        <a  href="<?php echo e(route('PostEdit', $post->id)); ?>" class="btn btn-primary">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    </div>
                                <?php endif; ?>
                        <a class="tittle" href="<?php echo e(route('PostShow', $post->post_url)); ?>"><?php echo e($post->post_title); ?></a>
                            <div class="date_comment">
                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(date("d-M", strtotime($post->created_at))); ?></a>
                                
                            </div>
                            <p style="padding: 0px;"><?php echo substr($post->post_content,0,100); ?></p>
                            
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
        </div>
    </section>
    <!-- End blog-2 area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/posts/myposts.blade.php ENDPATH**/ ?>