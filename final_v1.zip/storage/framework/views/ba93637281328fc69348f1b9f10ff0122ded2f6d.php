;
<?php $__env->startSection('content'); ?>
<section class="blog_all">
        <div class="container">
            <div class="row m0 blog_row">
                <div class="col-sm-8 main_blog">
                    <img src="<?php echo e(asset('public/uploads/postImages/' . $post->image)); ?>" alt="">
                    <div class="col-xs-1 p0">
                       <div class="blog_date">
                          <a> <?php echo e(date("d-M", strtotime($post->created_at))); ?></a>
                       </div>
                    </div>
                    <div class="col-xs-11 blog_content">
                        <a class="blog_heading" href="#"><?php echo e($post->post_title); ?> </a>
                        <a class="blog_admin" href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo e($post->user->fname . " " . $post->user->lname); ?></a>
                        <ul class="like_share">
                            <li>
                                <a href="#"><i class="fa fa-comment" aria-hidden="true"></i>
                                    <?php echo e(count($comments)); ?>

                            </a></li>
                            
                        </ul>
                        <p>
                            <?php echo $post->post_content; ?>

                        </p>
                    </div>
                    <!-----------------------------------COMMENT AREA START---------------------------------->
                    <?php if($post->is_comment == 1): ?>
                    <!---------------------------------Comment AREA--------------------------------->
                    <div class="post_comment">
                            <?php if(Session::has('message')): ?>
                            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
                        <?php elseif(Session::has('error')): ?>
                            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
                        <?php endif; ?>
                        <?php if(session('failed')): ?>
                            <script>
                              $( document ).ready(function() {
                                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
                              });
                              
                            </script>
                        <?php endif; ?>
                        
                        <h3>Post A Comment</h3>
                        <?php if(auth()->check()): ?>
                    <form class="comment_box" action="<?php echo e(route('CommentStore')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($post->id); ?>" name="post_id"/>
                           <div class="col-md-6">
                               <h4>Name</h4>
                           <input type="text" class="form-control input_box" id="" placeholder="" value="<?php echo e(auth()->user()->fname . " " . auth()->user()->lname); ?>" disabled>
                           </div>
                           <div class="col-md-6">
                               <h4>Email</h4>
                               <input type="text" class="form-control input_box" id="email" placeholder="" value="<?php echo e(auth()->user()->email); ?>" disabled>
                           </div>
                           <div class="col-md-12">
                               <h4>Your Comment</h4>
                               <textarea class="form-control input_box" placeholder="" name="comment_body"></textarea>
                               <button type="submit">Post Comment</button>
                           </div>
                        </form>
                        <?php else: ?>
                            <h3> Login to post a comment </h3>
                            <?php endif; ?>
                    </div>  
                    <?php endif; ?>
                    <div class="col-md-8">
                        
                            <div class="row blog_tow_row">
                                    
                                    
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card card-white post" id="comment_wraper<?php echo e($comment->id); ?>">
            <div class="post-heading">
                <div class="float-left meta">
                    <div class="title h5">
                        <a href="#"><b><?php echo e($comment->user->fname . " " . $comment->user->lname); ?></b></a>
                        made a comment. <span class="text-muted time"><?php echo e($comment->created_at->diffForHumans()); ?></span>
            <?php if(auth()->check() && $comment->user_id == auth()->user()->id): ?>
            <span class="text-right">
                    <a href="<?php echo e(route('CommentDelete', $comment->id)); ?>" class="btn btn-danger">
                        <i class="fa fa-trash"></i>
                    </a>
                </span>
                <?php else: ?> 
                
                <a class="badge badge-danger" data-toggle="collapse" href="#report<?php echo e($comment->id); ?>" role="button" aria-expanded="false" aria-controls="report" id="reportBtn<?php echo e($comment->id); ?>">
                        Report 
                    </a>
                    <div class="collapse" id="report<?php echo e($comment->id); ?>">
                        <div class="card card-body">
                            <form method="POST" action="<?php echo e(route('CommentReportStore')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>"/>
                                <div class="form-group">
                                    <label>Select Report Reason</label><br/>
                                    <input type="radio" value="Hate Speach" name="report_reason">
                                    <label>Hate Speach</label>
                                    <input type="radio" value="False Info"name="report_reason">
                                    <label>False Info</label>
                                    <input type="radio" value="Harrassment"name="report_reason">
                                    <label>Harrassment</label>
                                    <input type="submit" class="btn btn-info btn-sm" value="Report"/>
                                </div>
                               

                            </form>
                        </div>
                    </div>
                    <?php endif; ?>
                    </div>
                    
                </div>
            </div> 
            <div class="post-description"> 
                <p><?php echo e($comment->comment_body); ?></p>

            </div>
            <hr>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
       </div>
    </section>

    
<script>
    function reportComment(reason_id, comment_id){

        // alert(reason_id + " and " + comment_id);
        $('#report'+comment_id).hide();
        $('#reportBtn'+comment_id).hide();
        $('#reportedLabel'+comment_id).show();
        $('#comment_wraper'+comment_id).addClass('bg-danger');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/posts/show.blade.php ENDPATH**/ ?>