<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
       <div class="row blog_tow_row">
            <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
            <div class="row blog_tow_row mb-5 text-center">
                <a href="<?php echo e(route('CourseVideoCreate', $course_id)); ?>" class="btn btn-primary">Add New Video</a>
            </div>
            <?php endif; ?>

            <?php $__currentLoopData = $showcoursevideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="card">
                    <div class="card-body alert alert-success">
                            <div class="text-right">
                                    <a href="<?php echo e(route('CourseVideoDelete', $video->id)); ?>" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    
                                </div>
                    <h4><a class="tittle" href="<?php echo e(route('CourseVideoShow', [str_replace(" ", "-",$video->course->title), $video->id])); ?>"><?php echo e($video->title); ?></a></h4>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
       <div class="">
                    
            <div class="col-md-offset-1 col-md-8">
                    <hr/>
                    
                    <?php if(auth()->check() && auth()->user()->id == $course->user_id ): ?>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="table table-responsive p-5 bg-white">
                          <h2 class="mb-5"> List of User who Applied</h2>
                          <table class="table table-striped responsive">
                            <thead>
                              <tr>
                                <th>Id</th>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Date</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $index = 1; ?>
                              <?php $__currentLoopData = $appliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e($index++); ?></td>
                                <td> <a href="<?php echo e(route('ProfileUserAccount', $apply->user->id)); ?>">
                                    <?php echo e($apply->user->fname); ?> <?php echo e($apply->user->lname); ?> </a></td>
                                <td> <?php echo e($apply->user->email); ?></td>
                                  <td><?php echo e(date('d-M-Y', strtotime($apply->created_at))); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                
                          </table>
                        </div>
                      </div>
                    </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/show.blade.php ENDPATH**/ ?>