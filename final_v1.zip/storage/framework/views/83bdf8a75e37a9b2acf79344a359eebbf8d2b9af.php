<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
        <h1 class="text-center">My Courses: <?php echo e(count($showcourses)); ?></h1>
        <div class="row blog_tow_row mb-5 text-center">
            <a href="<?php echo e(route('CourseCreate')); ?>" class="btn btn-primary">Create New Course</a>
        </div>
        <?php endif; ?>
       <div class="row blog_tow_row">
            <?php $__currentLoopData = $showcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="renovation">
                    
                    <div class="renovation_content  <?php if($course->status == 2): ?> bg-info <?php endif; ?>">
                        <div class="text-right">
                                <?php if(auth()->check() && auth()->user()->isPro == 1 && auth()->user()->id == $course->user_id): ?>
                                    <a href="<?php echo e(route('CourseDelete', $course->id)); ?>" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a  href="<?php echo e(route('CourseEnroll',  $course->id )); ?>" class="btn btn-primary">
                                        <i class="fa fa-plus"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($course->status == 2): ?>
                                    <a onclick="courseMarkAsOpen(<?php echo e($course->id); ?>)" class="btn btn-green" title="Mark as Open">
                                            <i class="fa fa-check"></i>
                                        </a>
                                    <?php else: ?>
                                    <a onclick="courseMarkAsClosed(<?php echo e($course->id); ?>)" class="btn btn-green" title="Mark as Closed">
                                        <i class="fa fa-times"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                        
                    <a class="tittle" href="<?php echo e(route('CourseShow', [str_replace(" ", "-", $course->category->category_name), $course->id])); ?>"><?php echo e($course->title); ?></a>
                        <div class="date_comment">
                            <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($course->created_at); ?></a>
                            <a href="#"><i class="fa fa-commenting-o" aria-hidden="true"></i>3</a>
                        </div>
                        <p><?php echo substr($course->description,0,100); ?></p> 
                    </div>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
    </div>
</section>
<script>
function courseMarkAsClosed(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('CourseMarkAsClosed')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "course_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as closed")
                                  swal.fire('Closed', 'Marked as Closed', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
                    function courseMarkAsOpen(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('CourseMarkAsOpen')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "course_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as open")
                                  swal.fire('Opened', 'Marked as open', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
                    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/my_courses.blade.php ENDPATH**/ ?>