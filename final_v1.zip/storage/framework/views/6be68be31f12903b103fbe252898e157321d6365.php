<style>
	#header .logo {
    max-width: 20%;
	}
	.form-inputs p {
    overflow: hidden;
    height: auto;
		}
		.form-submit {
    overflow: hidden;
    height: auto;
		}
		.page-content {
    overflow: hidden;
    height: auto;
}
	</style>
	<?php if(!Auth::check() && 1 == 2): ?>
	<div class="login-panel">
			<section class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="page-content">
							<h2>Login</h2>
							<div class="form-style form-style-3">
							<form method="POST" action="<?php echo e(route('login')); ?>">
									<?php echo csrf_field(); ?>
									<div class="form-inputs clearfix">
										<p class="login-text">
											<input type="text" name="email" value="Username" >
											<i class="icon-user"></i>
											<?php if($errors->has('email')): ?>
												<span class="invalid-feedback">
													<strong><?php echo e($errors->first('email')); ?></strong>
												</span>
											<?php endif; ?>
										</p>
										<p class="login-password">
											<input type="password" name="password" value="Password">
											<i class="icon-lock"></i>
											<?php if($errors->has('password')): ?>
												<span class="invalid-feedback">
													<strong><?php echo e($errors->first('password')); ?></strong>
												</span>
											<?php endif; ?>
											
										</p>
									</div>
									<p class="form-submit login-submit">
										<input type="submit" value="Log in" class="button color small login-submit submit">
									</p>
									
								</form>
							</div>
						</div><!-- End page-content -->
					</div><!-- End col-md-6 -->
					<div class="col-md-6">
						<div class="page-content Register">
							<h2>Register Now</h2>
							<p>You can ask your question from the experts here at skoogle forum. Typically answer is posted around 1hour.</p>
							<a class="button color small signup">Create an account</a>
						</div><!-- End page-content -->
					</div><!-- End col-md-6 -->
				</div>
			</section>
		</div><!-- End login-panel -->
		
		<div class="panel-pop" id="signup">
			<h2>Register Now<i class="icon-remove"></i></h2>
			<div class="form-style form-style-3">
				<form>
					<div class="form-inputs clearfix">
						<p>
							<label class="required">Username<span>*</span></label>
							<input type="text">
						</p>
						<p>
							<label class="required">E-Mail<span>*</span></label>
							<input type="email">
						</p>
						<p>
							<label class="required">Password<span>*</span></label>
							<input type="password" value="">
						</p>
						<p>
							<label class="required">Confirm Password<span>*</span></label>
							<input type="password" value="">
						</p>
					</div>
					<p class="form-submit">
						<input type="submit" value="Signup" class="button color small submit">
					</p>
				</form>
			</div>
		</div><!-- End signup -->
		
		<div class="panel-pop" id="lost-password">
			<h2>Lost Password<i class="icon-remove"></i></h2>
			<div class="form-style form-style-3">
				<p>Lost your password? Please enter your username and email address. You will receive a link to create a new password via email.</p>
				<form>
					<div class="form-inputs clearfix">
						<p>
							<label class="required">Username<span>*</span></label>
							<input type="text">
						</p>
						<p>
							<label class="required">E-Mail<span>*</span></label>
							<input type="email">
						</p>
					</div>
					<p class="form-submit">
						<input type="submit" value="Reset" class="button color small submit">
					</p>
				</form>
				<div class="clearfix"></div>
			</div>
		</div>
		
<div id="header-top">
	<section class="container clearfix">
		<nav class="header-top-nav">
			<ul>
				
				
				<li><a href="" id="login-panel"><i class="icon-user"></i>Login Area</a></li>
			</ul>
		</nav>
		<div class="header-search">
			<form>
				<input type="text" value="Search here ..." onfocus="if(this.value=='Search here ...')this.value='';" onblur="if(this.value=='')this.value='Search here ...';">
				<button type="submit" class="search-submit"></button>
			</form>
		</div>
	</section>
</div>
<?php endif; ?>
<header id="header">
	<section class="container clearfix">
		<div class="logo">
			<a href="<?php echo e(route('ForumAll')); ?>">
				<img alt="" src="<?php echo e(asset('public/askme/images/logo.png')); ?>"  style="width: 70%"/>
			</a>
		</div>
		<nav class="navigation">
			<ul>
				
			<li class="ask_question"><a href="<?php echo e(route('Home')); ?>">News Feed</a></li>
			<li class="ask_question"><a href="<?php echo e(route('ForumAll')); ?>">Forum</a></li>
			<?php if(auth()->check()): ?>
			<li class="ask_question"><a href="<?php echo e(route('ForumMy')); ?>">My Questions</a></li>
			<?php endif; ?>
			<li class="ask_question"><a href="<?php echo e(route('ForumCreate')); ?>">Ask Question</a></li>
			<?php if(Auth::user()): ?>
			<li><a href="<?php echo e(route('ProfileAccount')); ?>">Profile</a></li>
			<li><a href="<?php echo e(route('LogOutSystem')); ?>">Logout</a></li>
			<?php endif; ?>
				
			</ul>
		</nav>
	</section><!-- End container -->
</header><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/layouts/askmepartials/topmenu.blade.php ENDPATH**/ ?>