<!-- Top Header_Area -->
<section class="top_header_area">
    <div class="container">
        <ul class="nav navbar-nav top_nav">
            <li><a href="#"><i class="fa fa-phone"></i>+92 (334) 909 6226</a></li>
            <li><a href="#"><i class="fa fa-envelope-o"></i>info@skoogle.com</a></li>
            <!--<li><a href="#"><i class="fa fa-clock-o"></i>Mon - Sat 12:00 - 20:00</a></li>-->
        </ul>
        
            <ul class="profile-wrapper">
                <li>
            <!-- user profile -->
                    <div class="profile">
                    
                    <?php if(auth()->check()): ?>
                    <a href="#" class="name">Welcome <?php echo e(auth()->user()->fname); ?>!</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('login')); ?>" class="name">Welcome Guest!</a>
                    <?php endif; ?>
                <!-- more menu --> 
                <ul class="menu">
                <li><a href="<?php echo e(route('ProfileAccount')); ?>">My Account</a></li>
                    
                    <?php if(auth()->check()): ?>
                    <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            </li>
                            
        </ul> 
    <!--        <ul class="nav navbar-nav navbar-right social_nav">
            <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>-->
    <!--<ul class="profile-wrapper">
        <li>
            
            <div class="profile">
                <img src="http://gravatar.com/avatar/0e1e4e5e5c11835d34c0888921e78fd4?s=80" />
                <a href="http://swimbi.com" class="name">swimbi.com</a>-->
    </div>
</section>
<!-- End Top Header_Area -->

<!-- Header_Area -->
<?php 
if(Route::currentRouteName() == 'Chatroom' || Route::currentRouteName() == 'ChatUserShow')
{
    $show = 0;
} else {
    $show = 1;
}
?>
<?php if($show != 0): ?>
<nav class="navbar navbar-default header_aera" id="main_navbar">
    <div class="container">
        <!-- searchForm -->
        <div class="searchForm">
            <form action="#" class="row m0">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
                    <input type="search" name="search" class="form-control" placeholder="Type & Hit Enter">
                    <span class="input-group-addon form_hide"><i class="fa fa-times"></i></span>
                </div>
            </form>
        </div><!-- End searchForm -->
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="col-md-2 p0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#min_navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo e(route('Home')); ?>"><img src="<?php echo e(asset('public/askme/images/logo.png')); ?>" alt=""></a>
            </div>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="col-md-10 p0">
            <div class="collapse navbar-collapse" id="min_navbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('Home')); ?>">Newsfeed</a></li>
                    
                    <li><a href="<?php echo e(route('PostAll')); ?>">Articles</a></li>
                    <li><a href="<?php echo e(route('ServicesAll')); ?>">Services</a></li>
                    <li><a href="<?php echo e(route('ProjectsAll')); ?>">Projects</a></li>
                    <li class="dropdown submenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                        <ul class="dropdown-menu other_dropdwn">
                            <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
                            <li><a href="<?php echo e(route('CourseMy')); ?>">My Courses </a></li>
                            <?php endif; ?>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('CourseCategoryShow',$course->id)); ?>"><?php echo e($course->category_name); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                        </ul>
                        
                    </li>
                <li><a href="<?php echo e(route('JobAll')); ?>">Career</a></li>
                    <li><a href="<?php echo e(route('ForumAll')); ?>">Forum</a></li>
                    <li><a href="<?php echo e(route('Chatroom')); ?>">Chat</a></li>
                    <?php if(!auth()->check()): ?>
                    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('/signup')); ?>">Sign Up</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                    <?php endif; ?>
                    
                </ul>
            </div><!-- /.navbar-collapse -->
        </div>
    </div><!-- /.container -->
</nav>
<?php endif; ?>
<!-- End Header_Area --><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/layouts/homepartials/menu.blade.php ENDPATH**/ ?>