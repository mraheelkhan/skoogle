<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
    <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
<?php elseif(Session::has('error')): ?>
    <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
      });
      
    </script>
<?php endif; ?>
    <!--------------------ARTICLES START------------------------->
    <?php if(auth()->check() && auth()->user()->isPro != 1): ?>
    <section class="serviceoffer">
            <div class="container">
                <div class="row service_skill">
                    <div class="service_test"> 
                
                    <p>READY TO OFFER YOUR SKILLS?</p>
                    <p>Earn 10 skoogle coins &amp; unlock the Matching Game by posting your first service. Not sure what to offer? <a href="#">Take our skill test</a></p> 
                    </div>
                    <div class="service_offer">
                        <li><a href="<?php echo e(route('ServiceOffer')); ?>">Offer a Service</a></li>
                    </div>
                    </div>
                </div>
            
        </section>

        <?php endif; ?>


    <section class="blog_tow_area">
        <div class="container">

                <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
                <h3 class="text-center">My Services: <a href="<?php echo e(route('ServiceMy')); ?>"><?php echo e(count($services)); ?> - Show </a></h3>
                <div class="row blog_tow_row mb-5 text-center" style="margin: 20px 1px;">
                    <a href="<?php echo e(route('ServiceCreate')); ?>" class="btn btn-primary">Create New Service</a>
                </div>
                <?php endif; ?>

                
           <div class="row blog_tow_row"  style="margin: 50px 1px;">
               <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6">
                    <div class="renovation">
                        
                        <div class="renovation_content">
                            <a class="clipboard" href="#"><i class="fa fa-clipboard" aria-hidden="true"></i></a>
                        <a class="tittle" href="<?php echo e(route('ServiceShow', $service->url)); ?>"><?php echo e($service->title); ?></a>
                            <div class="date_comment">
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo e($service->user->fname); ?></a>
                                <a href="#"><i class="fa fa-commenting-o" aria-hidden="true"></i><?php echo e($service->price); ?> - PKR</a>
                            </div>
                            <p><?php echo substr($service->description,0,100); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
           </div>
        </div>
    </section>
    <!-- End blog-2 area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/services/index.blade.php ENDPATH**/ ?>