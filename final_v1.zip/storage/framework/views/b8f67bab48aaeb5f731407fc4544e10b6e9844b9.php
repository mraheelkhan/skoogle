;
<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
       <div class="row blog_tow_row">

            <div class="col-md-8">
                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
            <form action="<?php echo e(route('CourseStore')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title"> Enter title of the course</label>
                <input type="text" class="form-control input_box" name="title" id="title" placeholder="Enter Title of the Post" value="<?php echo e(old('title')); ?>" onchange="urlGenerator()" focused/>
                </div>
                <div class="form-group">
                    <label for="title"> Select Category</label>
                    <select  name="category_id" id="category_id" class="form-control">
                        <option value="" disabled selected>Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="title"> Your Course Content</label>
                    <textarea rows="10"  cols="10"  value="<?php echo e(old('description')); ?>" class="" name="description" id="description"></textarea>
                    <script>
                            CKEDITOR.replace( 'description' );
                        </script>
                        
                </div>  

                    <div class="form-group">
                        <input type="submit" name="submit" value="Publish Post" class="btn btn-primary"/>
                    </div>
            </form>

            </div>
       </div>
    </div>
</section>

<script>
    function urlGenerator(){
        var title = $('#title').val();
        var random = Math.floor(Math.random() * 1000000) + 1000000;
        title = title.replace(/[^a-zA-Z0-9]/g, '-');
        //title = title.replace(/[^a-zA-Z ]/g, "-");
        var newUrl = $('#post_url').val(title + random);
        console.log(title + random);
    }

    $(document).ready(function() {
        $('#category_id').select2();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/create.blade.php ENDPATH**/ ?>