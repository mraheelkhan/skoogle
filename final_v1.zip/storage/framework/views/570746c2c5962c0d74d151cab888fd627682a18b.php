<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <script>
      $( document ).ready(function() {
        swal("Success", "<?php echo e(session('success')); ?>", "success");
      });
      
    </script>
<?php endif; ?>
<?php
$user = Auth::user();
?>
<!-- some CSS styling changes and overrides -->
<style>
.kv-avatar .krajee-default.file-preview-frame,.kv-avatar .krajee-default.file-preview-frame:hover {
    margin: 0;
    padding: 0;
    border: none;
    box-shadow: none;
    text-align: center;
}
.kv-avatar {
    display: inline-block;
}
.kv-avatar .file-input {
    display: table-cell;
    width: 213px;
}
.kv-reqd {
    color: red;
    font-family: monospace;
    font-weight: normal;
}
</style>
<div class="box box-info">


<div class="box-header with-border">
  <h3 class="box-title">Profile</h3>
</div>
<!-- /.box-header -->
<!-- form start -->
<div id="kv-avatar-errors-1" class="center-block" style="width:800px;display:none"></div>
<form class="form-horizontal" action="<?php echo e(action('UserController@update', $user->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<input name="_method" type="hidden" value="PATCH">
<input name="profile" type="hidden" value="1">
<div class="box-body" >
<div class="row">
  <div class="col-md-4 text-center">
      <div class="kv-avatar">
          <div class="file-loading">
              <input id="avatar-1" name="avatar-1" type="file">
          </div>
      </div>
      <div class="kv-avatar-hint"><small>Select file < 1000 KB</small></div>
  </div> 
  <div class="col-md-8">
    <div class="form-group">
      <label for="fname" class="col-sm-3 control-label">First Name</label>

      <div class="col-sm-9">
        <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name" autocomplete="off" value="<?php echo e($user->fname); ?>" require >
        <?php if($errors->has('fname')): ?>
              <span class="text-red">
                  <strong><?php echo e($errors->first('fname')); ?></strong>
              </span>
          <?php endif; ?>
      </div>
    </div>
    <div class="form-group">
      <label for="lname" class="col-sm-3 control-label">Last Name</label>

      <div class="col-sm-9">
        <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name" value="<?php echo e($user->lname); ?>" autocomplete="off" require>
        <?php if($errors->has('lname')): ?>
              <span class="text-red">
                  <strong><?php echo e($errors->first('lname')); ?></strong>
              </span>
          <?php endif; ?>
      </div>
    </div>

    <div class="form-group">
      <label for="email" class="col-sm-3 control-label">Email</label>

      <div class="col-sm-9">
        <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e($user->email); ?>" autocomplete="off" require>
        <?php if($errors->has('email')): ?>
              <span class="text-red">
                  <strong><?php echo e($errors->first('email')); ?></strong>
              </span>
          <?php endif; ?>
      </div>
    </div>


    <div class="form-group">
      <label for="phonenumber" class="col-sm-3 control-label">Phone Number</label>

      <div class="col-sm-9">
        <input type="text" class="form-control" id="phonenumber" name="phonenumber" placeholder="Phone Number" value="<?php echo e($user->phonenumber); ?>" autocomplete="off" require>
        <?php if($errors->has('phonenumber')): ?>
              <span class="text-red">
                  <strong><?php echo e($errors->first('phonenumber')); ?></strong>
              </span>
          <?php endif; ?>
      </div>
    </div>

  </div>
  </div>

</div>
  <!-- /.box-body -->
  <div class="box-footer">
    <a href="<?php echo url('/admins');; ?>" class="btn btn-default">Cancel</a>
    <button type="submit" class="btn btn-info pull-right">Update</button>
  </div>
  <!-- /.box-footer -->
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/profile.blade.php ENDPATH**/ ?>