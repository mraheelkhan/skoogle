;
<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
       <div class="row blog_tow_row">

            <div class="col-md-8">
                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
            <form action="<?php echo e(route('ServiceStore')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title"> Enter title of the services</label>
                <input type="text" class="form-control input_box" name="title" id="title" placeholder="Enter Title of the Post" value="<?php echo e(old('title')); ?>" onchange="urlGenerator()" focused/>
                </div>
                <div class="form-group">
                    <label for="title"> Url (none-editable)</label>
                    <input type="text" class="form-control input_box" name="url" id="url" value="<?php echo e(old('url')); ?>" placeholder="URL of the Post" readonly/>
                </div>
                <div class="form-group">
                    <label for="price"> Enter Price of the services</label>
                <input type="text" class="form-control input_box" name="price" id="price" placeholder="Enter Title of the Post" value="<?php echo e(old('price')); ?>" onchange="urlGenerator()" focused/>
                </div>
                <div class="form-group">
                    <label for="title"> Select Category</label>
                    <select  name="category_id" id="category_id" class="form-control">
                        <option value="" disabled selected>Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="title"> Your service Content</label>
                    <textarea rows="10"  cols="50"  value="<?php echo e(old('description')); ?>" class="" name="description" id="description"></textarea>
                    <script>
                            CKEDITOR.replace( 'description' );
                        </script>
                        
                </div>  

                    <div class="form-group">
                        <input type="submit" name="submit" value="Publish Service" class="btn btn-primary"/>
                    </div>
            </form>

            </div>
       </div>
    </div>
</section>

<script>
    $(document).ready(function() {
        $('#category_id').select2();
    });

    function urlGenerator(){
        var title = $('#title').val();
        var random = Math.floor(Math.random() * 1000000) + 1000000;
        title = title.replace(/[^a-zA-Z0-9]/g, '-');
        //title = title.replace(/[^a-zA-Z ]/g, "-");
        var newUrl = $('#url').val(title + random);
        console.log(title + random);
    }

    function readURL(input) {
        $('#imagePreview').show();
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#imagePreview')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/services/create.blade.php ENDPATH**/ ?>