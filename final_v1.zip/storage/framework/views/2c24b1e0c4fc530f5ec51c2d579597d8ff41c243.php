<?php
$user = Auth::user();
?>
 <!-- Main Header -->
 <header class="main-header">
<!-- Logo -->
<a href="<?php echo url('/home');; ?>" class="logo">
  <!-- mini logo for sidebar mini 50x50 pixels -->
  <span class="logo-mini"><b>Sk</b></span>
  <!-- logo for regular state and mobile devices -->
  <span class="logo-lg"><b>Skoogle</b></span>
</a>

<!-- Header Navbar -->
<nav class="navbar navbar-static-top" role="navigation">
  <!-- Sidebar toggle button-->
  <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
    <span class="sr-only">Toggle navigation</span>
  </a>
  <!-- Navbar Right Menu -->
  <div class="navbar-custom-menu">
    <ul class="nav navbar-nav">

      <!-- Notifications Menu -->
      <li class="dropdown notifications-menu">
        <!-- Menu toggle button -->
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <i class="fa fa-bell-o"></i>
          <span class="label label-warning"><?php echo e(Auth::user()->unreadNotifications->count()); ?></span>
        </a>
        <ul class="dropdown-menu">
          <li class="header">You have <?php echo e(Auth::user()->unreadNotifications->count()); ?>  unread notification(s)</li>
          <li>
            <!-- Inner Menu: contains the notifications -->
            <ul class="menu">
              <?php $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><!-- start notification -->
                <a href="<?php echo e($notification->data['letter']['redirectURL']); ?>" title="<?php echo e($notification->data['letter']['title']); ?>" data-notif-id="<?php echo e($notification->id); ?>">
                  <i class="fa fa-users text-aqua"></i> <?php echo e($notification->data['letter']['title']); ?>

                </a>
              </li>
              <!-- end notification -->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>
          <?php if(Auth::user()->unreadNotifications->count() > 0): ?>
          <li class="footer"><a href="#">View all</a></li>
          <?php endif; ?>
        </ul>
      </li>
      
      
      <!-- User Account Menu -->
      <li class="dropdown user user-menu">
        <!-- Menu Toggle Button -->
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
          <!-- The user image in the navbar-->
          <img src="<?php echo e(asset('public/img/staff/'.$user->avatar)); ?>" class="user-image" alt="User Image">
          <!-- hidden-xs hides the username on small devices so only the image appears. -->
          <span class="hidden-xs"><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></span>
        </a>
        <ul class="dropdown-menu">
          <!-- The user image in the menu -->
          <li class="user-header">
            <img src="<?php echo e(asset('public/img/staff/'.$user->avatar)); ?>" class="img-circle" alt="User Image">
            <p>
              <?php echo e($user->fname); ?> <?php echo e($user->lname); ?>

              <small>Member since <?php echo e($user->created_at->format('M, Y')); ?></small>
             
              
            </p>
          </li>
          <li class="user-footer">
            <div>
              <a href="<?php echo url('/profile');; ?>" class="btn btn-primary btn-flat">Profile</a>
              <a href="<?php echo url('/changepassword');; ?>" class="btn btn-warning btn-flat">Change Password</a>
              <a class="btn btn-danger btn-flat" href="<?php echo e(route('logout')); ?>"
                  onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                  <?php echo e(__('Logout')); ?>

              </a>

              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                  <?php echo csrf_field(); ?>
              </form>
            </div>
            
          </li>
        </ul>
      </li>
      
    </ul>
  </div>
</nav>
</header><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/layouts/partials/topnav.blade.php ENDPATH**/ ?>