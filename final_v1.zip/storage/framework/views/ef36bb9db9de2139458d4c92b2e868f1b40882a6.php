;
<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
       <div class="row blog_tow_row">

            <div class="col-md-8">
                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                    <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
            <form action="<?php echo e(route('CourseVideoStore')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="course_id" value="<?php echo e($course_id); ?>"/>
                <div class="form-group">
                    <label for="title"> Enter title of the course video</label>
                <input type="text" class="form-control input_box" name="title" id="title" placeholder="Enter Title of the Post" value="<?php echo e(old('title')); ?>" onchange="urlGenerator()" focused/>
                </div>
                <div class="form-group">
                    <label for="file"> Upload Video File</label>
                <input type="file" class="form-control input_box" name="file" id="file"/>
                </div>

                <div class="form-group">
                    <label for="title"> Your video Content</label>
                    <textarea rows="10"  cols="10"  value="<?php echo e(old('description')); ?>" class="" name="description" id="description"></textarea>
                    <script>
                            CKEDITOR.replace( 'description' );
                        </script>
                        
                </div>  

                    <div class="form-group">
                        <input type="submit" name="submit" value="Publish Post" class="btn btn-primary"/>
                    </div>
            </form>

            </div>
       </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/createVideo.blade.php ENDPATH**/ ?>