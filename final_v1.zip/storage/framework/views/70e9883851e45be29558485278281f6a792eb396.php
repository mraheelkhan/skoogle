<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
    <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
<?php elseif(Session::has('error')): ?>
    <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
      });
      
    </script>
<?php endif; ?>
    <!--------------------ARTICLES START------------------------->
    
    <section class="blog_tow_area">
        <div class="container">

                
                <?php if(auth()->check()): ?>
                <h3 class="text-center">My Projects: <a href="<?php echo e(route('ProjectMy')); ?>"><?php echo e(count($projects)); ?> - Show </a></h3>
                <div class="row blog_tow_row mb-5 text-center" style="margin: 20px 1px;">
                    <a href="<?php echo e(route('ProjectCreate')); ?>" class="btn btn-primary">Create New Project</a>
                </div>
                <?php endif; ?>

                
           <div class="row blog_tow_row"  style="margin: 50px 1px;">
               <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6">
                    <div class="renovation ">
                        
                        <div class="renovation_content  <?php if($project->status == 2): ?> bg-info <?php endif; ?>">
                            <a class="clipboard" href="#"><i class="fa fa-clipboard" aria-hidden="true"></i></a>
                        <a class="tittle" href="<?php echo e(route('ProjectShow', $project->url)); ?>"><?php echo e($project->title); ?> 
                            <?php if($project->status == 2): ?> <span class="badge badge-info"> *Closed</span><?php endif; ?>
                        </a>
                            <div class="date_comment">
                                <a href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo e($project->user->fname); ?></a>
                                <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($project->end_date); ?> </a>
                            </div>
                            <p><?php echo substr($project->description,0,100); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
           </div>
        </div>
    </section>
    <!-- End blog-2 area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/projects/index.blade.php ENDPATH**/ ?>