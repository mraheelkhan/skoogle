<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
    <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
<?php elseif(Session::has('error')): ?>
    <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
      });
      
    </script>
<?php endif; ?>
    <!--------------------ARTICLES START------------------------->
    <section class="blog_all">
            <div class="container">
                <div class="row m0 blog_row">
                    <div class="col-sm-8 main_blog">
                        <img src="<?php echo e(asset('public/uploads/postImages/' . $post->image)); ?>" alt="">
                        <div class="col-xs-1 p0">
                           <div class="blog_date">
                                <?php echo e(date("d-M", strtotime($post->created_at))); ?>

                           </div>
                        </div>
                        <div class="col-xs-11 blog_content">
                            <a class="blog_heading" href="#"><?php echo e($post->post_title); ?></a>
                            <a class="blog_admin" href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo e($post->user->fname . " " . $post->user->lname); ?></a>
                            
                            <?php echo $post->post_content; ?>

                        </div>
                        <!-----------------------------------COMMENT AREA START---------------------------------->
                        
                    <!---------------------------------Comment AREA--------------------------------->
                       
                    </div>
                    <!-------------------------------END Comment-------------------------------------->
                    <div class="col-sm-4 widget_area">
                        <div class="resent">
                            <h3>RECENT POSTS</h3>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="media">
                                    <div class="media-left">
                                        <a href="#">
                                            
                                        </a>
                                    </div>
                                    <div class="media-body">
                                            <a class="" href="<?php echo e(route('PostShow', $post->post_url)); ?>">
                                                <?php echo e($post->post_title); ?>

                                            </a>
                                        <h6><?php echo e($post->created_at); ?></h6>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </div>
                        
                        <div class="resent">
                            <h3>Projects</h3>
                            <ul class="tag">
                                
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('ProjectShow', $project->url)); ?>"><?php echo e($project->title); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
        </section>
    <section class="blog_tow_area">
        <div class="container">
           <div class="row blog_tow_row">
              <h2 class="text-center m-5" style="margin: 20px 1px;">Latest Articles</h2>
               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                <div class="col-md-4 col-sm-6">
                    <div class="renovation">
                        <img src="<?php echo e(asset('public/uploads/postImages/' . $post->image)); ?>"  style="border: 1px solid black;"  alt="">
                        <div class="renovation_content">
                            <a class="clipboard" href="#"><i class="fa fa-clipboard" aria-hidden="true"></i></a>
                        <a class="tittle" href="<?php echo e(route('PostShow', $post->post_url)); ?>"><?php echo e($post->post_title); ?></a>
                            <div class="date_comment">
                                <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(date("d-M", strtotime($post->created_at))); ?></a>
                                
                            </div>
                            <p><?php echo substr($post->post_content,0,100); ?></p>
                        </div>
                    </div>
                </div>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
               
           </div>
        </div>
    </section>

    <section class="blog_tow_area">
            <div class="container">
               <div class="row blog_tow_row">
                  <h2 class="text-center m-5" style="margin: 20px 1px;">Latest Jobs</h2>
                   <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                    <div class="col-md-4 col-sm-6">
                        <div class="renovation">
                            <img src="<?php echo e(asset('public/uploads/postImages/' . $job->image)); ?>"  style="border: 1px solid black;"  alt="">
                            <div class="renovation_content"  style="height: 200px;">
                                <a class="clipboard" style="background: #000;" href="#"><i class="fa fa-file" aria-hidden="true"></i></a>
                            <a class="tittle" href="<?php echo e(route('JobShow', $job->id)); ?>"><?php echo e($job->job_title); ?></a>
                                <div class="date_comment">
                                    <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e(date("d-M", strtotime($job->created_at))); ?></a>
                                    
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                   
               </div>
            </div>
        </section>
    <!-- End blog-2 area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/home/home.blade.php ENDPATH**/ ?>