<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
        
        <?php if(auth()->check()): ?>
        <h1 class="text-center">My Projects: <?php echo e(count($projects)); ?></h1>
        <div class="row blog_tow_row mb-5 text-center">
            <a href="<?php echo e(route('ProjectCreate')); ?>" class="btn btn-primary">Create New Project</a>
        </div>
        <?php endif; ?>
       <div class="row blog_tow_row">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="renovation">
                    
                    <div class="renovation_content <?php if($project->status == 2): ?> bg-info <?php endif; ?>">
                            
                            <?php if(auth()->check() && auth()->user()->id == $project->user_id): ?>
                            <div class="text-right">
                                    <a href="<?php echo e(route('ProjectDelete', $project->id)); ?>" class="btn btn-danger" title="Delete Project">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <?php if($project->status == 2): ?>
                                    <a onclick="projectMarkAsOpen(<?php echo e($project->id); ?>)" class="btn btn-green" title="Mark as Open">
                                            <i class="fa fa-check"></i>
                                        </a>
                                    <?php else: ?>
                                    <a onclick="projectMarkAsClosed(<?php echo e($project->id); ?>)" class="btn btn-green" title="Mark as Closed">
                                        <i class="fa fa-times"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        
                    <a class="tittle" href="<?php echo e(route('ProjectShow', $project->url)); ?>"><?php echo e($project->title); ?> 
                            <?php if($project->status == 2): ?> <span class="badge badge-info"> *Closed</span><?php endif; ?>
                        </a>
                        <div class="date_comment">
                            <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i><?php echo e($project->end_date); ?></a>
                            
                        </div>
                        <p><?php echo substr($project->description,0,100); ?></p> 
                    </div>
                    
                </div>
            </div>
            <script>
                    function projectMarkAsClosed(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('ProjectMarkAsClosed')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "project_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as closed")
                                  swal.fire('Closed', 'Marked as Closed', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
                    function projectMarkAsOpen(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('ProjectMarkAsOpen')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "project_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as open")
                                  swal.fire('Opened', 'Marked as open', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
                      </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/projects/my_projects.blade.php ENDPATH**/ ?>