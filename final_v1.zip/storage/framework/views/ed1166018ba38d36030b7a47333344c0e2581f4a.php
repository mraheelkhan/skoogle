;
<?php $__env->startSection('content'); ?>
<section class="blog_all">
        <div class="container">
            <div class="row m0 blog_row">
                <div class="col-md-8 main_blog">
                    
                    <div class="col-xs-1 p0">
                       <div class="blog_date">
                          
                       </div>
                    </div>
                    <div class="col-xs-11 blog_content">
                        <a class="blog_heading" href="#"><?php echo e($service->title); ?> </a>
                        <a class="blog_admin" href="#"><i class="fa fa-user" aria-hidden="true"></i><?php echo e($service->user->fname . " " . $service->user->lname); ?></a>
                        <ul class="like_share">
                            <li>
                                <a href="#">
                                    <i class="fa fa-money" aria-hidden="true"></i>
                                    <?php echo e($service->price); ?> - PKR
                                </a>
                            </li>
                            
                        </ul>
                        <p>
                            <?php echo $service->description; ?>

                        </p>
                    </div>
                   
                </div>
                <div class="col-md-4">
                        <?php if(auth()->check()): ?>
                        <p class="mt-5">
                                <?php if(auth()->user()->id == $service->user_id ): ?>
                                <span class="alert alert-success"> 
                                    Your Service! </span>
                                    <?php if($service->status == 2): ?>
                                    <span class="badge"> Status : Closed</span>
                                    <?php endif; ?>
                                </span>
                                    
                                <?php elseif($service->status == 2): ?>
                                <span class="alert alert-info"> service Closed!</span>
                                <?php else: ?>
                                    <?php if(count($ifApplied) < 1 ): ?>
                                        
                                        <form action="<?php echo e(route('ServiceApply')); ?>" method="POST"method="post" enctype="multipart/form-data" role="form">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="service_id" value="<?php echo e($service->id); ?>"/>
                                            <input type="submit" class="btn btn-primary  py-2 px-4" value="Apply Service" />
                                        </form>
                                    <?php else: ?>
                                    
                                        <span class="alert alert-success"> Already Applied!</span>
                                        <a href="<?php echo e(route('ServiceApplyCancel', $service->id)); ?>">Cancel Apply</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                        </p>
                        <?php else: ?>
                            <p class="mt-5">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-danger py-2 px-4">Login to Apply Project</a>
                            </p>
                        <?php endif; ?>
                </div>
                <div class="">
                    
                        <div class="col-md-offset-1 col-md-8">
                                <hr/>
                                <?php if(auth()->check() && auth()->user()->id == $service->user_id ): ?>
                                <div class="row">
                                  <div class="col-md-8">
                                    <div class="table table-responsive p-5 bg-white">
                                      <h2 class="mb-5"> List of User who Applied</h2>
                                      <table class="table table-striped responsive">
                                        <thead>
                                          <tr>
                                            <th>Id</th>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Date</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <?php $index = 1; ?>
                                          <?php $__currentLoopData = $appliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <td><?php echo e($index++); ?></td>
                                            <td> <a href="<?php echo e(route('ProfileUserAccount', $apply->user->id)); ?>">
                                                <?php echo e($apply->user->fname); ?> <?php echo e($apply->user->lname); ?> </a></td>
                                            <td> <?php echo e($apply->user->email); ?></td>
                                              <td><?php echo e(date('d-M-Y', strtotime($apply->created_at))); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                            
                                      </table>
                                    </div>
                                  </div>
                                </div>
                                <?php endif; ?>
                        </div>
                    </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/services/show.blade.php ENDPATH**/ ?>