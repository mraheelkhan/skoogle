<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
        <div class="row blog_tow_row">
                
                <p>
                     <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                       Show Already Enrolled 
                     </a>
                   </p>
                   <div class="collapse" id="collapseExample">
                     <div class="card card-body">
                       
                            <table class="table text-center">
                                    <thead>
                                        <th>No</th>
                                        <th class="text-center">Name</th>
                                        <th  class="text-center">Email</th>
                                        <th class="text-center">Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $index = 1; ?>
                                        <?php $__currentLoopData = $enrolledUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrolledUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                           <td><?php echo e($index++); ?></td>
                                           <td><?php echo e($enrolledUser->user->fname . " " . $enrolledUser->user->lname); ?></td>
                                           <td><?php echo e($enrolledUser->user->email); ?></td>
                                           <td> 
                                                <a  href="<?php echo e(route('CourseUserEnrollDelete', $enrolledUser->id)); ?>" class="btn btn-danger">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                           </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                           <th>No</th>
                                           <th class="text-center">Name</th>
                                           <th class="text-center">Email</th>
                                           <th class="text-center">Action</th>
                                    </tfoot>
                                </table>
                    </div>
                   </div>
        </div>
        <hr>
       <div class="row blog_tow_row">
           <div class="video text-center">
              
             <h2 class="mb-5">All User Lists</h2>

             <table class="table text-center">
                 <thead>
                     <th>No</th>
                     <th class="text-center">Name</th>
                     <th  class="text-center">Email</th>
                     <th class="text-center">Action</th>
                 </thead>
                 <tbody>
                     <?php $index = 1; ?>
                     <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($index++); ?></td>
                        <td><?php echo e($user->fname . " " . $user->lname); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td> 
                            <a  href="<?php echo e(route('CourseUserEnroll', [$user->id, $course->id])); ?>" class="btn btn-success">
                                <i class="fa fa-plus"></i>
                            </a>
                        </td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
                 <tfoot>
                        <th>No</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Email</th>
                        <th class="text-center">Action</th>
                 </tfoot>
             </table>
           
        </div>
       </div>
    </div>
</section>
<script>
    function enrollUser(){

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/enroll_course.blade.php ENDPATH**/ ?>