<?php $__env->startSection('content'); ?>
<?php if(Session::has('message')): ?>
  <p class="alert alert-success"><?php echo Session::get('message'); ?></p>
<?php elseif(Session::has('error')): ?>
  <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
<?php endif; ?>
<?php if(session('failed')): ?>
    <script>
      $( document ).ready(function() {
        swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
      });
      
    </script>
<?php endif; ?>



      <div class="site-section bg-light">
            <div class="container">
              <div class="row">
                <div class="col-md-12 mb-5 mb-md-0" data-aos="fade-up" data-aos-delay="100">
                  <h2 class="mb-5 h3">Recent Jobs</h2>
                  <div class="rounded border jobs-wrap">
      
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(route('JobShow', $job->id)); ?>" class="job-item d-block d-md-flex align-items-center  border-bottom fulltime" style="<?php echo e(($job->status == 2) ? 'background: #d40606;' : ''); ?>">
                      
                      <div class="job-details h-100">
                        <div class="p-3 align-self-center">
                        <h3><?php echo e($job->job_title); ?></h3>
                          <div class="d-block d-lg-flex">
                            <div class="mr-3"><span class="icon-suitcase mr-1"></span> <?php echo e($job->organization->deptname); ?></div>
                            <div class="mr-3"><span class="icon-room mr-1"></span> <?php echo e($job->job_location); ?></div>
                            <div><span class="icon-money mr-1"></span> PKR <?php echo e($job->salary_range); ?></div>
                          </div>
                        </div>
                      </div>
                      <div class="job-category align-self-center">
                        <div class="p-3">
                          
                        <span class="text-<?php if($job->job_type == 'fulltime'): ?>info <?php elseif($job->job_type == 'freelance'): ?>warning <?php elseif($job->job_type == 'parttime'): ?>danger <?php endif; ?> p-2 rounded border border-<?php if($job->job_type == 'fulltime'): ?>info <?php elseif($job->job_type == 'freelance'): ?>warning <?php elseif($job->job_type == 'parttime'): ?>danger <?php endif; ?>"><?php echo e(ucfirst($job->job_type)); ?></span>
                        
                        </div>
                        <?php if(auth()->check() && $job->user_id == auth()->user()->id && $job->status != 2 && auth()->user()->organization_id != 0): ?>
                        <div class="p-3">
                        <span onclick="jobMarkAsClosed(<?php echo e($job->id); ?>)" class="text-primary p-2 rounded border filled border-primary"> 
                          <i class="fas fa-trash-alt"></i>Close Job
                        </span>
                        </div>
                        <?php endif; ?>
                        <?php echo e(($job->status == 2) ? 'CLOSED' : ''); ?>

                        
                       
                      </div>  
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
                    
      
                  </div>
      
                  
                </div>

      
                </div>
              </div>
            </div>
          </div>

  <script>
  function jobMarkAsClosed(id){
    event.preventDefault();
    routeURL = "<?php echo e(route('JobMarkAsClosed')); ?>";
    $.ajax({
        url: routeURL,
        method: 'POST',
        data: {
            "job_id" : id,
            "_token" : "<?php echo e(csrf_token()); ?>"
        },
        success: function(data){
            console.log(data);
            if(data.success == 1){
                swal.fire('Closed', 'Marked as Closed', "success");
                location.reload();
            } else {
                swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
            }
            
        },
        error: function(error){
            console.log(error);
        }
    });
  }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.job', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/jobs/index.blade.php ENDPATH**/ ?>