<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
        <h1 class="text-center">My Services: <?php echo e(count($services)); ?></h1>
        <div class="row blog_tow_row mb-5 text-center">
            <a href="<?php echo e(route('ServiceCreate')); ?>" class="btn btn-primary">Create New Service</a>
        </div>
        <?php endif; ?>
       <div class="row blog_tow_row">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="renovation">
                    
                    <div class="renovation_content <?php if($service->status == 2): ?> bg-info <?php endif; ?>">
                            <?php if(auth()->check() && auth()->user()->isPro == 1 && auth()->user()->id == $service->user_id): ?>
                            <div class="text-right">
                                    <a href="<?php echo e(route('ServiceDelete', $service->id)); ?>" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <?php if($service->status == 2): ?>
                                    <a onclick="serviceMarkAsOpen(<?php echo e($service->id); ?>)" class="btn btn-green" title="Mark as Open">
                                            <i class="fa fa-check"></i>
                                        </a>
                                    <?php else: ?>
                                    <a onclick="serviceMarkAsClosed(<?php echo e($service->id); ?>)" class="btn btn-green" title="Mark as Closed">
                                        <i class="fa fa-times"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        
                    <a class="tittle" href="<?php echo e(route('ServiceShow', $service->url)); ?>"><?php echo e($service->title); ?></a>
                        <div class="date_comment">
                            <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($service->created_at); ?></a>
                            
                        </div>
                        <p><?php echo substr($service->description,0,100); ?></p> 
                    </div>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
    </div>
</section>

<script>
                    function serviceMarkAsClosed(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('ServiceMarkAsClosed')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "service_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as closed")
                                  swal.fire('Closed', 'Marked as Closed', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
                    function serviceMarkAsOpen(id){
                      event.preventDefault();
                      routeURL = "<?php echo e(route('ServiceMarkAsOpen')); ?>";
                      $.ajax({
                          url: routeURL,
                          method: 'POST',
                          data: {
                              "service_id" : id,
                              "_token" : "<?php echo e(csrf_token()); ?>"
                          },
                          success: function(data){
                              console.log(data);
                              if(data.success == 1){
                                  console.log("successfully marked as open")
                                  swal.fire('Opened', 'Marked as open', "success");
                                  location.reload();
                              } else {
                                  swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                              }
                              
                          },
                          error: function(error){
                              console.log(error);
                          }
                      });
                    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/services/my_services.blade.php ENDPATH**/ ?>