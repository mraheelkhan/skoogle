<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
            <?php if(Session::has('message')): ?>
            <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
        <?php elseif(Session::has('error')): ?>
            <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
        <?php endif; ?>
        <?php if(session('failed')): ?>
            <script>
              $( document ).ready(function() {
                swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
              });
              
            </script>
        <?php endif; ?>
        <?php if(auth()->check() && auth()->user()->isPro == 1): ?>
        <div class="row blog_tow_row mb-5 text-center">
            <a href="<?php echo e(route('CourseCreate')); ?>" class="btn btn-primary">Create New Course</a>
        </div>
        <?php endif; ?>
       <div class="row blog_tow_row">
            <?php $__currentLoopData = $showcourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6">
                <div class="renovation">
                    
                    <div class="renovation_content">
                        <div class="text-right">
                                <?php if(auth()->check() && auth()->user()->isPro == 1 && auth()->user()->id == $course->user_id): ?>
                                    <a href="<?php echo e(route('CourseDelete', $course->id)); ?>" class="btn btn-danger">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a  href="<?php echo e(route('CourseEdit', $course->id)); ?>" class="btn btn-primary">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a>
                                    <form action="<?php echo e(route('CourseApply')); ?>" method="POST"method="post" enctype="multipart/form-data" role="form">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>"/>
                                        <input type="submit" class="btn btn-primary  py-2 px-4" value="Apply Service" />
                                    </form>
                                </a>
                                    <a  href="<?php echo e(route('CourseApplyCancel', $course->id)); ?>" class="btn btn-danger">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                </div>
                        
                    <a class="tittle" href="<?php echo e(route('CourseShow', [str_replace(" ", "-", $course->category->category_name), $course->id])); ?>"><?php echo e($course->title); ?></a>
                        <div class="date_comment">
                            <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($course->created_at); ?></a>
                            <a href="#"><i class="fa fa-commenting-o" aria-hidden="true"></i>3</a>
                        </div>
                        <p><?php echo substr($course->description,0,100); ?></p>
                        
                    </div>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div>
    </div>
</section>
<script>
                    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/courses/courses_category.blade.php ENDPATH**/ ?>