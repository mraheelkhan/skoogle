;
<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
       <div class="row blog_tow_row">
            
            <div class="col-md-8">
                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
            <form action="<?php echo e(route('PostStore')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="title"> Enter title of the post</label>
                <input type="text" class="form-control input_box" name="title" id="title" placeholder="Enter Title of the Post" value="<?php echo e(old('title')); ?>" onchange="urlGenerator()" focused/>
                </div>
                <div class="form-group">
                    <label for="title"> Url (none-editable)</label>
                    <input type="text" class="form-control input_box" name="post_url" id="post_url" value="<?php echo e(old('post_url')); ?>" placeholder="URL of the Post" readonly/>
                </div>
                <div class="form-group">
                    <label for="image"> Upload Image</label>
                <input type="file" class="form-control input_box" name="image" id="image" onchange="readURL(this);" />
                <img id="imagePreview" src="http://placehold.it/180" alt="your image" style="display:none; width:100%; height: 100%" />    
            </div>
                <div class="form-group">
                    <label for="title"> Select Category</label>
                    <select  name="category_id" id="category_id" class="form-control">
                        <option value="" disabled selected>Select Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="title"> Your Post Content</label>
                    <textarea rows="10"  cols="10"  value="<?php echo e(old('post_content')); ?>" class="" name="post_content" id="post_content"></textarea>
                    <script>
                            CKEDITOR.replace( 'post_content' );
                        </script>
                        
                </div>
                <div class="form-group">
                        <label for="title"> Allowed Comment?</label>
                        <select name="is_comment" id="is_comment"  value="<?php echo e(old('is_comment')); ?>" class="form-control">
                            <option value="1"> Allowed </option>
                            <option value="0"> Not Allowed </option>
                        </select>
                    </div>

                    <div class="form-group">
                        <input type="submit" name="submit" value="Publish Post" class="btn btn-primary"/>
                    </div>
            </form>

            </div>
       </div>
    </div>
</section>

<script>
    function urlGenerator(){
        var title = $('#title').val();
        var random = Math.floor(Math.random() * 1000000) + 1000000;
        title = title.replace(/[^a-zA-Z0-9]/g, '-');
        //title = title.replace(/[^a-zA-Z ]/g, "-");
        var newUrl = $('#post_url').val(title + random);
        console.log(title + random);
    }

    function readURL(input) {
        $('#imagePreview').show();
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#imagePreview')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/posts/create.blade.php ENDPATH**/ ?>