<?php $__env->startSection('content'); ?>

<section class="serviceoffer">
        <?php if(Session::has('message')): ?>
        <p class="alert alert-success"><?php echo Session::get('message'); ?></p>    
    <?php elseif(Session::has('error')): ?>
        <p class="alert alert-danger"><?php echo Session::get('error'); ?></p>
    <?php endif; ?>
    <?php if(session('failed')): ?>
        <script>
          $( document ).ready(function() {
            swal.fire("Failed", "<?php echo Session::get('error'); ?>", "error");
          });
          
        </script>
    <?php endif; ?>
    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
</section>
<section class="mainaccount">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="mainprofile">
                    
                     <h3><?php echo e($profile->fname . " " . $profile->lname); ?>  </h3>
                    <li>
                         <a href="#"><span><?php echo e($profile->profile->address); ?></span></a>
                    </li>
                    <ul>
                    
                     </ul>
                     <hr>
                     
                     <div class="row_badges">
                        

                     <div class="col-sm-6 right">
                            

                    </div>
                    
                    </div>

                     <!------<ul>

                </ul>----------->
            </div>

            </div>



            <div class="col-lg-8">
                
            </div>
            <hr>
            <div class="introduction">
                <h3>Hey, I'm <?php echo e($profile->fname . " " . $profile->lname); ?>!</h3>
                <h5><?php echo e($profile->profile->address); ?> | Member <?php echo e($profile->created_at->diffForHumans()); ?></h5>
                <p> <?php echo e($profile->profile->description); ?></p>
                
            
            </div>
            
            
            <hr>
            <div class="provide-service">
                <h4>Offered Services</h4>
                <p>Not sure what to offer? <a href="#">Take our skill test</a></p>
                <div class="">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2" style="border: 1px solid #000;">
                            <a href="<?php echo e(route('ServiceShow', $service->url)); ?>"> <?php echo e($service->title); ?></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php if(auth()->check() && $profile->id == auth()->user()->id): ?>
                <div class="service-box">
                    <ul><i class="fa fa-plus-circle" style="font-size: 24px"></i>
                    <a href="<?php echo e(route('ServiceCreate')); ?>">Add Service</a>
                  </ul>
                    
                </div>
                <?php endif; ?>
            </div>
            
            <hr/>

            <?php if(count($certificates) > 0): ?>
            <div class="provide-service">
                    <div class="">
                            <h4>Uploaded Certificates</h4>
                            <?php $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4" style="border: 1px solid #000;">

                                <img width="100%" src="<?php echo e(asset('public/uploads/certificates/' . $certify->filename)); ?>"/>
                                    <a href="<?php echo e(route('ServiceShow', $certify->id)); ?>"> <?php echo e($certify->title); ?></a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
            </div>
            <hr/>
            <?php else: ?>

            <?php endif; ?>

            <div class="col-md-8">
                <?php if(auth()->user()->isPro == 1): ?>
            <h2> You are Professional </h2>
                <?php else: ?>
                <a href="<?php echo e(route('ProfileApplyPro', auth()->user()->id)); ?>" class="btn btn-success btn-lg"> Apply for Pro</a>
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#certificates">
                        Upload Certificates
                      </button>
                <?php endif; ?>
            </div>
            
            </div>
        </div>
        
    </div>
  
    
    
</section>
<div class="modal fade" id="certificates" tabindex="-1" role="dialog" aria-labelledby="certificatesLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="certificatesLabel">Start New Chat</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                    <form action="<?php echo e(route('ProfileUploadCertificate')); ?>" method="POST"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="form-group">
                            <input type="text" placeholder="Enter title of certificate" class="form-control input_box" name="title"/>
                        </div>
                        <div class="form-group">
                                <input type="file" name="image" class="form-control" required>
                            </div>  
                        <div class="form-group">
                                <button type="submit" name='submit' class="btn btn-primary">Upload</button>
                        </div>
                        <div class="form-group"></div>
                        <div class="form-group"></div>
                    </form>
            </div>
            
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/profile/profile.blade.php ENDPATH**/ ?>