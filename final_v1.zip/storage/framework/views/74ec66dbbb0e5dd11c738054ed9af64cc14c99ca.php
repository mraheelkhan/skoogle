;
<?php $__env->startSection('content'); ?>
<section class="blog_tow_area">
    <div class="container">
       <div class="row blog_tow_row">

            <div class="col-md-8">
                    <?php if($errors->any()): ?>
                    <ul class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
            
                    <div class="col-md-offset-4 col-md-6">
                        <img src="<?php echo e(asset('public/img/test.png')); ?>"/>
                    </div>
                    <div class="col-md-offset-6 col-md-6">
                        <h2 class="text-center"> Offer your first Service</h2>
                        <p class="text-center"> Not sure what to offer?</p>
                        <p class="text-center">
                            <a href="<?php echo e(route('ServiceOfferCategory')); ?>"> Take our Skills Quiz</a>
                        </p>
                    </div>
            </div>
       </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/services/offer.blade.php ENDPATH**/ ?>