<?php $__env->startSection('content'); ?>

<section class="serviceoffer">
    
</section>
<section class="mainaccount">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="mainprofile">
                    
                     <h3><?php echo e($profile->fname . " " . $profile->lname); ?>  </h3>
                    <li>
                         <a href="#"><span><?php echo e($profile->profile->address); ?></span></a>
                    </li>
                    <ul>
                    
                     </ul>
                     <hr>
                     
                     <div class="row_badges">
                        <div class="col-sm-6">
                           <i class="fa fa-trophy" aria-hidden="true"></i>
                           <div class="popup" onclick="myFunction()"><p>Quickster</p>
                              <span class="popuptext" id="myPopup">Members with this badge are among the quickest responders on Skoogle. Consistently reply in under 4 hours to earn and keep your Quickster badge.</span>
                            </div><hr>

                           <i class="fa fa-shield" aria-hidden="true"></i>
                           <div class="popup" onclick="myFunction()"><p>Veteran</p>
                              <span class="popuptext" id="myPopup">The veteran badge is reserved for experienced members with at least 3 deals.</span>
                            </div><hr>
                           <i class="fa fa-star-half-o" aria-hidden="true"></i>
                           <div class="popup" onclick="myFunction()"><p>Recruiter</p>
                              <span class="popuptext" id="myPopup">Recruiters are members that have got 5 or more members to join. Want to earn an awesome Recruiter Badge? Invite your friends to join Skoogle!</span>
                            </div><hr>
                           <i class="fa fa-star" aria-hidden="true"></i>
                           <div class="popup" onclick="myFunction()"><p>Helper</p>
                              <span class="popuptext" id="myPopup">How neighborly! Members with this badge have fulfilled another member’s request.</span>
                            </div><hr>

                           
                        </div>

                     <div class="col-sm-6 right">
                            <i class="fa fa-diamond" aria-hidden="true"></i>
                            <div class="popup" onclick="myFunction()"><p>Circulator</p>
                              <span class="popuptext" id="myPopup">The coveted Circulator badge is awarded to members who invigorate the Symbiotic Economy by actively circulating substantial amounts of Skoogle.</span>
                            </div><hr>
                            <i class="fa fa-bolt" aria-hidden="true"></i>
                            <div class="popup" onclick="myFunction()"><p>Talented</p>
                              <span class="popuptext" id="myPopup">The talented badge is awarded to gifted members who have offered more than 5 services. The more you give, the more you get.</span>
                            </div><hr>
                            <i class="fa fa-empire" aria-hidden="true"></i>
                            <div class="popup" onclick="myFunction()"><p>Centurian</p>
                              <span class="popuptext" id="myPopup">his honorable badge is reserved for our most praiseworthy troops — those with 100 or more deals. Join the top ranks of the Symbiotic Economy.You’ll earn 100 for this achievement.</span>
                            </div><hr>

                    </div>
                    
                    </div>

                     <!------<ul>

                </ul>----------->
            </div>

            </div>



            <div class="col-lg-8">
                
            </div>
            <hr>
            <div class="col-lg-8 introduction">

                <form action="<?php echo e(route('ProfileUserEditAccountStore')); ?>" method="POST"  enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" class="form-control input_box" name="fname" value="<?php echo e($profile->fname); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control input_box" name="lname" value="<?php echo e($profile->lname); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control input_box" name="address" value="<?php echo e($profile->profile->address); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control input_box" name="phone" value="<?php echo e($profile->phonenumber); ?>"/>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control input_box" name="description" value="<?php echo e($profile->profile->description); ?>"/>
                    </div>  
                    <div class="form-group">
                            <input type="file" name="image" value="<?php echo e(old('image')); ?>" class="form-control" required>
                        </div>  
                    <div class="form-group">
                            <button type="submit" name='submit' class="btn btn-primary">Sign Up</button>
                    </div>
                    <div class="form-group"></div>
                    <div class="form-group"></div>
                </form>
                
            
            </div>
            
            </div>
        </div>
        
    </div>
    
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/profile/edit.blade.php ENDPATH**/ ?>