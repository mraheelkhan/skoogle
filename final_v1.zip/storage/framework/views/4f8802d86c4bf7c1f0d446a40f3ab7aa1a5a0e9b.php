<?php $__env->startSection('topbanner'); ?>
<div class="breadcrumbs">
		<section class="container">
			<div class="row">
				<div class="col-md-12">
					<h1><?php echo e($question->question_title); ?></h1>
				</div>
				<div class="col-md-12">
					<div class="crumbs">
                    <a href="<?php echo e(route('ForumAll')); ?>">Home</a>
						<span class="crumbs-span">/</span>
						<a href="<?php echo e(route('ForumAll')); ?>">Questions</a>
						<span class="crumbs-span">/</span>
                    <span class="current"><?php echo e($question->question_title); ?></span>
					</div>
				</div>
			</div><!-- End row -->
		</section><!-- End container -->
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
        .about-author .author-bio {
            overflow: hidden;
            height: auto;
        }
        .question-vote {
            height: auto;
        }
        .commentlist li .comment-meta {
            height: auto;
        }
        .comment-author a {
            color: #78797b;
        }
        .commentlist li p {
            font-size: 14px;
            color: #000;
        }
    
    </style>    
<div class="col-md-9"   style="overflow: unset; height: auto;">
        <article class="question single-question question-type-normal">
            <h2>
               
                        <?php echo e($question->question_title); ?>

               
            </h2>
            
            <div class="question-inner">
                        
                <div class="clearfix"></div>
                <div class="question-desc">
                <p><?php echo e($question->question_body); ?>}</p>
                </div>
                <div class="question-details">
                    <span class="question-answered question-answered-done"><i class="icon-ok"></i>
                        <?php echo e($question->status); ?></span>
                    
                </div>
                <span class="question-category"><a href="#"><i class="icon-folder-close"></i>
                    <?php echo e($question->category->category_name); ?></a></span>
                <span class="question-date"><i class="icon-time"></i><?php echo e($question->created_at->diffForHumans()); ?></span>
                <span>
                        <button type="button" onclick="reportshow()" class="btn btn-info report-question btn-sm" >
                                Report
                              </button>
                            
                </span>
                <script>
                    function reportshow(){
                        $('#reportsection').show();
                    }
                </script>
                
                
                <ul class="single-question-vote">
                    
                    
                </ul>
                <div class="clearfix"></div>
            </div>
        </article>
        
        <div class="about-author clearfix" id="reportsection" style="display: none;">
                <div class="">
                    <h2>Select Report Reason</h2><br/>
                        <form method="POST" action="<?php echo e(route('QuestionReportStore')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>"/>
                                <div class="form-group col-md-3">
                                    <label>Hate Speach</label>
                                    <input type="radio" value="Hate Speach" name="report_reason">
                                </div>
                                <div class="form-group col-md-3">
                                    <label>False Info</label>
                                    <input type="radio" value="False Info"name="report_reason">
                                </div>
                                <div class="form-group col-md-3">
                                    <label>Harrassment</label>
                                    <input type="radio" value="Harrassment"name="report_reason">
                                </div>
                                <div class="form-group col-md-3">
                                    <input type="submit" class="btn btn-info btn-sm" value="Report"/>
                                </div>
                               
    
                            </form>
                  </div>
        </div>
        <div class="about-author clearfix">
            <div class="author-image">
                <a href="#" original-title="admin" class="tooltip-n"><img alt="" src="<?php echo e(asset('public/img/staff/'.$question->user->avatar)); ?>"></a>
            </div>
            <div class="author-bio">
            <h4>About the Author -  <?php echo e($question->user->fname); ?> <?php echo e($question->user->lname); ?></h4>
                [[UPDATE IT]]Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed viverra auctor neque. Nullam lobortis, sapien vitae lobortis tristique.
            </div>
        </div><!-- End about-author -->
        
        <div id="commentlist" class="page-content">
        <div class="boxedtitle page-title"><h2>Answers ( <span class="color"><?php echo e(count($answers)); ?></span> )</h2></div>
            <ol class="commentlist clearfix">
                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="comment" style=" <?php if($answer->isSolution == 1): ?> background:#b8ff94 <?php endif; ?>">
                    <div class="comment-body comment-body-answered clearfix"> 
                        <div class="avatar"><img alt="" src="<?php echo e(asset('public/img/staff/'.$answer->user->avatar)); ?>"></div>
                        <div class="comment-text">
                            <div class="author clearfix">
                                <div class="comment-author"><a href="#"><?php echo e($answer->user->fname); ?> <?php echo e($answer->user->lname); ?></a></div>
                                <?php if( auth()->check() && $solved == 0 && $question->user_id == auth()->user()->id): ?>
                                <div class='comment-author' style="float:right">
                                    <button class="btn btn-success" onclick="markAsSolution(<?php echo e($answer->id); ?>)" title="Mark as Solution"><i class="icon-ok"></i></button>
                                </div>
                                <?php endif; ?>
                                <?php if( auth()->check() && $answer->user_id == auth()->user()->id): ?>
                                <button class="label label-danger" onclick="markAsDeleted(<?php echo e($answer->id); ?>)" title="Delete your Answer">Delete</button>
                                <?php endif; ?>
                                
                                
                                <div class="comment-meta">
                                    <div class="date"><i class="icon-time"></i><?php echo e($answer->created_at->diffForHumans()); ?> </div> 
                                </div>
                                 
                            </div>
                            <div class="text"><p><?php echo e($answer->answer_body); ?></p>
                            </div>
                            <?php if($answer->isSolution == 1): ?>
                            <div class="question-answered question-answered-done"><i class="icon-ok"></i>Best Solution</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </ol><!-- End commentlist -->
        </div><!-- End page-content -->
        
        <div id="respond" class="comment-respond page-content clearfix">
            <div class="boxedtitle page-title"><h2>Leave Your Answer</h2></div>
            <form action="<?php echo e(route('QuestionAnswerStore')); ?>" method="POST" id="commentform" class="comment-form">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>" />
                <div id="respond-textarea">
                    <p>
                        <label class="required" for="answer_body">Answer<span>*</span></label>
                        <textarea id="answer_body" name="answer_body" aria-required="true" cols="58" rows="8"></textarea>
                    </p>
                </div>
                <p class="form-submit">
                    <input name="submit" type="submit" id="submit" value="Post your answer" class="button small color">
                </p>
            </form>
        </div>
        
        
    </div>
<script>
    function test(){
        alert('lsajfdlsajd');
    }
    function markAsSolution(id){
        data = {
            "question_id" : "<?php echo e($question->id); ?>",
            "answer_id" : id,
            '_token' : "<?php echo e(csrf_token()); ?>"
        }
        routeURL = "<?php echo e(route('AnswerMarkAsSolution')); ?>";
        $.ajax({
            url: routeURL,
            method: 'POST',
            data: {
                "question_id" : <?php echo e($question->id); ?>,
                "answer_id" : id,
                "_token" : "<?php echo e(csrf_token()); ?>"
            },
            success: function(data){
                console.log(data);
                if(data.success == 1){
                    swal.fire('success', 'Mark Status Updated', "success");
                    location.reload();
                } else {
                    swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                }
                
            },
            error: function(error){
                console.log(error);
            }
        });
    }

    function markAsDeleted(id){
        routeURL = "<?php echo e(route('forum.admindelete')); ?>";
        $.ajax({
            url: routeURL,
            method: 'POST',
            data: {
                "answer_id" : id,
                "_token" : "<?php echo e(csrf_token()); ?>"
            },
            success: function(data){
                console.log(data);
                if(data.success == 1){
                    swal.fire('deleted', 'Marked as Deleted', "success");
                    location.reload();
                } else {
                    swal.fire('Already Solved', 'You cannot mark 2 answer as solution', "error");
                }
                
            },
            error: function(error){
                console.log(error);
            }
        });
    }

</script>   



<div class="modal fade" id="reportquestion" tabindex="-1" role="dialog" aria-labelledby="reportquestion" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="reportquestion">Report Question</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              
            </div>
            
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.askme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skoogle\resources\views/forum/singlequestion.blade.php ENDPATH**/ ?>