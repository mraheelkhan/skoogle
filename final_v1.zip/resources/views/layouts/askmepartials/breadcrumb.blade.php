<div class="breadcrumbs">
		<section class="container">
			<div class="row">
				<div class="col-md-12">
					<h1>@yield('title')</h1>
				</div>
				
			</div><!-- End row -->
		</section><!-- End container -->
	</div>