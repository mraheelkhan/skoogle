<aside class="col-md-3 sidebar">
        <div class="widget widget_stats">
            <h3 class="widget_title">Stats</h3>
            <div class="ul_list ul_list-icon-ok">
                <ul>
                    <li><i class="icon-question-sign"></i>Questions ( <span>20</span> )</li>
                    <li><i class="icon-comment"></i>Answers ( <span>50</span> )</li>
                </ul>
            </div>
        </div>
        
        
        
        
        <div class="widget widget_highest_points">
            <h3 class="widget_title">Highest points</h3>
            <ul>
                <li>
                    <div class="author-img">
                        <a href="#"><img width="60" height="60" src="../ask-me/images/demo/admin.jpg" alt=""></a>
                    </div> 
                    <h6><a href="#">admin</a></h6>
                    <span class="comment">12 Points</span>
                </li>
                <li>
                    <div class="author-img">
                        <a href="#"><img width="60" height="60" src="../ask-me/images/demo/avatar.png" alt=""></a>
                    </div> 
                    <h6><a href="#">vbegy</a></h6>
                    <span class="comment">10 Points</span>
                </li>
                <li>
                    <div class="author-img">
                        <a href="#"><img width="60" height="60" src="../ask-me/images/demo/avatar.png" alt=""></a>
                    </div> 
                    <h6><a href="#">ahmed</a></h6>
                    <span class="comment">5 Points</span>
                </li>
            </ul>
        </div>
        
        <div class="widget widget_tag_cloud">
            <h3 class="widget_title">Tags</h3>
            <a href="#">projects</a>
            <a href="#">Portfolio</a>
            <a href="#">Wordpress</a>
            <a href="#">Html</a>
            <a href="#">Css</a>
            <a href="#">jQuery</a>
            <a href="#">2code</a>
            <a href="#">vbegy</a>
        </div>
        
        <div class="widget">
            <h3 class="widget_title">Recent Questions</h3>
            <ul class="related-posts">
                <li class="related-item">
                    <h3><a href="#">This is my first Question</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div class="clear"></div><span>Feb 22, 2014</span>
                </li>
                <li class="related-item">
                    <h3><a href="#">This Is My Second Poll Question</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div class="clear"></div><span>Feb 22, 2014</span>
                </li>
            </ul>
        </div>
        
    </aside>